package com.nec.aim.uid.client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class PingIP {

	public static void runSystemCommand(String command) {
		try {
			Process p = Runtime.getRuntime().exec(command);
			BufferedReader inputStream = new BufferedReader(
					new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8));
			String allString = "";
			String s = "";
			// reading output stream of the command
			while ((s = inputStream.readLine()) != null) {
				allString = allString + s;
			}
			System.out.println(allString.length());
			System.out.println(allString);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {

		String ip = "google.com";
		runSystemCommand("ping " + ip);
	}
}