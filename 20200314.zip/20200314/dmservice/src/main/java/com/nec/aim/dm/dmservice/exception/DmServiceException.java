package com.nec.aim.dm.dmservice.exception;
public class DmServiceException extends RuntimeException {

	private static final long serialVersionUID = 2626082645396399681L;

	public DmServiceException(String message) {
		super(message);
	}

	public DmServiceException(Throwable cause) {
		super(cause);
	}

	public DmServiceException(String message, Throwable cause) {
		super(message, cause);
	}

}
