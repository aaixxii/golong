package com.nec.aim.dm.dmservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.nec.aim.dm.dmservice.socket.HeatBeatSocketServer;

@SpringBootApplication
public class DmserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DmserviceApplication.class, args);
		if (args.length > 3 && args[1] != null && args[2] != null) {
			String socketPort = args[1];
			String allConnStr = args[2];
			HeatBeatSocketServer server = new HeatBeatSocketServer();
			server.start(Integer.valueOf( socketPort),allConnStr);
		}		
	}
}
