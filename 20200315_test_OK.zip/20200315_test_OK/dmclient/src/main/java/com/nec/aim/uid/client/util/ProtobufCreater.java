package com.nec.aim.uid.client.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.google.common.collect.Lists;
import com.google.protobuf.ByteString;

import jp.co.nec.aim.message.proto.AIMMessages.PBInquiryJobInfoInternal;
import jp.co.nec.aim.message.proto.AIMMessages.PBMapInquiryJobResult;
import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResult;
import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;
import jp.co.nec.aim.message.proto.BatchTypeProto.BatchType;
import jp.co.nec.aim.message.proto.BusinessMessage.E_BIOMETRIC_DATA_FORMAT;
import jp.co.nec.aim.message.proto.BusinessMessage.E_REQUESET_TYPE;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBiometricElement;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBiometricsData;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBCandidate;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataBlock;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataElement;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataGroup;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBResponse;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;
import jp.co.nec.aim.message.proto.ExtractService.ExtractRequest;
import jp.co.nec.aim.message.proto.ExtractService.ExtractResponse;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyRequest;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyResponse;
import jp.co.nec.aim.message.proto.SyncService.SyncRequest;
import jp.co.nec.aim.message.proto.SyncService.SyncResponse;

public class ProtobufCreater {
	
	public ProtobufCreater() {		
	}
	
	public  PBMapInquiryJobResult MapInquiryJobResult(long topLevelJobId,
			long planId, int msgSequence, String value, long matchCount,long readCount) {
			
		int requestIndex = 7;
		int containerId = 1;
		int messageSequence = msgSequence;
		long jobTimeout = 10;
		int internalMaxCandidates = 10;
		int mrId = 10;

		PBMapInquiryJobResult.Builder builder = PBMapInquiryJobResult
				.newBuilder();
		builder.setMrId(mrId);
		builder.setPlanId(planId);
		PBInquiryJobInfoInternal.Builder jobInfo = builder.getJobInfoBuilder();
		jobInfo.setTopLevelJobId(topLevelJobId);
		jobInfo.setRequestIndex(requestIndex);
		jobInfo.setContainerId(containerId);
		jobInfo.setMessageSequence(messageSequence);
		jobInfo.setJobTimeout(jobTimeout);
		jobInfo.setInternalMaxCandidates(internalMaxCandidates);
		jobInfo.setMuJobPopTime(7);		
		PBBusinessMessage result =  createPBBusinessMessage();
		builder.setResult(result);		
		return builder.build();
	}
	
	public SyncResponse createSyncResponse() {
		SyncResponse.Builder syncRes = SyncResponse.newBuilder();
		syncRes.setBatchJobId(1);
		syncRes.setType(BatchType.ENROLL);
		PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();		
		PBRequest.Builder pq = PBRequest.newBuilder();
		pq.setRequestId("12");
		pq.setRequestType(E_REQUESET_TYPE.INSERT_REFURL_DEFAULT);		
		pq.setEnrollmentId("enrollId1");
		PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
		pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
		PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
		pdBiData.setBiometricElement(pbEl.build());
		pq.setBiometricsData(pdBiData.build());
		pbMsg.setRequest(pq.build());
		PBResponse.Builder pbRes = PBResponse.newBuilder();
		pbRes.setStatus("0:sucess");
		PBDataBlock.Builder dataBlock = PBDataBlock.newBuilder();
		PBTemplateInfo.Builder template = PBTemplateInfo.newBuilder();
		template.setData(ByteString.copyFrom("template data".getBytes()));
		template.setReferenceId("enrollId1");
		dataBlock.setTemplateInfo(template.build());
		pbMsg.setDataBlock(dataBlock.build());
		syncRes.addBusinessMessage(pbMsg.build().toByteString());
		return syncRes.build();
		
	}
	
	
	public  SyncRequest createInsertRequest(long batchId, String requestId, String externalId, E_REQUESET_TYPE reqType) {
		SyncRequest.Builder insertReq = SyncRequest.newBuilder();
		insertReq.setBatchJobId(batchId);
		insertReq.setType(BatchType.ENROLL);
		PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();		
		PBRequest.Builder pq = PBRequest.newBuilder();
		pq.setRequestId(requestId);
		pq.setEnrollmentId(externalId);
		pq.setRequestType(reqType);	
		PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
		pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
		PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
        if (reqType == E_REQUESET_TYPE.INSERT_REFID_DEFAULT) {
        	PBTemplateInfo.Builder template = PBTemplateInfo.newBuilder();
        	template.setReferenceId(externalId);
		} else if (reqType == E_REQUESET_TYPE.INSERT_REFURL_DEFAULT) {
			pbEl.setFilePath("http://192.168.22.117/UID/DownLoad/Image/FingerLess/file/9999999.tar");
			pbEl.setChecksum("e453d4650f180f121b308af1e9270381");
		} 		
		pdBiData.setBiometricElement(pbEl.build());
		pq.setBiometricsData(pdBiData.build());
		pbMsg.setRequest(pq.build());
		insertReq.addBusinessMessage(pbMsg.build().toByteString());
		return insertReq.build();
	}
	
	public IdentifyRequest createIdentifyRequest(long batchId, String requestId, String externalId, E_REQUESET_TYPE type) {
		IdentifyRequest.Builder iqyReq = IdentifyRequest.newBuilder();
		iqyReq.setBatchJobId(batchId);
		iqyReq.setType(BatchType.IDENTIFY);
		PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();			
		PBRequest.Builder pq = PBRequest.newBuilder();
		pq.setRequestId( requestId);
		if (externalId != null) {
		    pq.setEnrollmentId(externalId);
		}		
		pq.setRequestType(type);
		pq.setMaxResults(10);
		pq.setTargetFpir(1);
		PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
		pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
		PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
		PBTemplateInfo.Builder template = PBTemplateInfo.newBuilder();
		if (type == E_REQUESET_TYPE.IDENTIFY_REFID_DEFAULT) {			
			template.setReferenceId(externalId);			
		} else if (type == E_REQUESET_TYPE.IDENTIFY_DEFAULT) {		   
		   byte[] templateData =  FileUtil.getDataFromFile("/C:/Users/000001A006PBP/Desktop/test/133_template_data");
			template.setData(ByteString.copyFrom(templateData));
		}
		pbEl.setTemplateInfo(template.build());
		pdBiData.setBiometricElement(pbEl.build());
		pq.setBiometricsData(pdBiData.build());
		pbMsg.setRequest(pq).build();
		iqyReq.addBusinessMessage(pbMsg.build().toByteString());
		return iqyReq.build();
	}
	
	public IdentifyRequest createIdentifyRequestWithErr(E_REQUESET_TYPE type) {
		IdentifyRequest.Builder iqyReq = IdentifyRequest.newBuilder();
		iqyReq.setBatchJobId(11111);
		iqyReq.setType(BatchType.IDENTIFY);
		PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();			
		PBRequest.Builder pq = PBRequest.newBuilder();
		pbMsg.setRequest(pq.build());
		iqyReq.addBusinessMessage(pbMsg.build().toByteString());
		return iqyReq.build();		
	}
	
	public  ExtractRequest createExtractRequest(long batchId, String requestId, String externalId) {
		ExtractRequest.Builder extReq = ExtractRequest.newBuilder();
		extReq.setBatchJobId(batchId);
		extReq.setType(BatchType.EXTRACT);
		PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();			
		PBRequest.Builder pq = PBRequest.newBuilder();		
		pq.setRequestId(requestId);
		pq.setEnrollmentId(externalId);		
		pq.setRequestType(E_REQUESET_TYPE.INSERT_REFID_DEFAULT);
		PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
		pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
		PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
		pbEl.setFilePath("http://192.168.22.117/UID/DownLoad/Image/FingerLess/file/9999999.tar");
		pbEl.setChecksum("e453d4650f180f121b308af1e9270381");
		pdBiData.setBiometricElement(pbEl.build());
		pq.setBiometricsData(pdBiData.build());
		pbMsg.setRequest(pq.build());
		extReq.addBusinessMessage(pbMsg.build().toByteString());
		return extReq.build();
	}
	
	public  ExtractRequest createExtractRequestHaveErr() {
		ExtractRequest.Builder extReq = ExtractRequest.newBuilder();		
		extReq.setType(BatchType.EXTRACT);
		PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();			
		PBRequest.Builder pq = PBRequest.newBuilder();
		pq.setRequestId("request1");
		pq.setEnrollmentId("enroll1");
		pq.setRequestType(E_REQUESET_TYPE.INSERT_REFID_DEFAULT);
		PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
		pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
		PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
		pbEl.setFilePath("/testpath");
		pbEl.setChecksum("checkSun");
		pdBiData.setBiometricElement(pbEl.build());
		pq.setBiometricsData(pdBiData.build());
		pbMsg.setRequest(pq.build());
		extReq.addBusinessMessage(pbMsg.build().toByteString());
		return extReq.build();
	}
	
	public static ExtractResponse createExtractResponse() {
		 ExtractResponse.Builder extRes =  ExtractResponse.newBuilder();
		 extRes.setType(BatchType.EXTRACT);
		 extRes.setBatchJobId(11111);
			PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();			
			PBRequest.Builder pq = PBRequest.newBuilder();			
			pq.setRequestId("request1");
			pq.setEnrollmentId("enroll1");
			pq.setRequestType(E_REQUESET_TYPE.INSERT_REFID_DEFAULT);
			pbMsg.setRequest(pq.build());
			PBResponse.Builder pbRes = PBResponse.newBuilder();
			pbRes.setStatus("0:success");
			pbMsg.setResponse(pbRes.build());
			PBDataBlock.Builder pblock = PBDataBlock.newBuilder();
			PBTemplateInfo.Builder template = PBTemplateInfo.newBuilder();
			template.setData(ByteString.copyFrom("extract result".getBytes()));
			template.setReferenceId("enroll1");
			pblock.setTemplateInfo(template.build());
			pbMsg.setDataBlock(pblock.build());
			extRes.addBusinessMessage(pbMsg.build().toByteString());
			return extRes.build();	
	}	
	
	
	public PBMuExtractJobResult createPBMuExtractJobResult(long muId, long lotJobId, long feJobid) {
		PBBusinessMessage pbMsg = createPBBusinessMessage();
		PBMuExtractJobResultItem.Builder muItem = PBMuExtractJobResultItem.newBuilder();
		muItem.setJobId(feJobid);
		muItem.setResult(pbMsg.toByteString());
		PBMuExtractJobResult.Builder pBMuExtractJobResult = PBMuExtractJobResult.newBuilder();
		pBMuExtractJobResult.setMuId(muId);
		pBMuExtractJobResult.setLotJobId(lotJobId);
		pBMuExtractJobResult.addResult(0, muItem.build());
		return pBMuExtractJobResult.build();
	}
	
	public IdentifyResponse createIdentifyResponse() {
		IdentifyResponse.Builder iqyRes = IdentifyResponse.newBuilder();
		iqyRes.setBatchJobId(11111);
		iqyRes.setType(BatchType.IDENTIFY);
		PBBusinessMessage pbmes = createPBBusinessMessage();
		iqyRes.addBusinessMessage(pbmes.toByteString());
		return iqyRes.build();	
	}
	
	public PBBusinessMessage createPBBusinessMessage() {
		PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();		
		PBRequest.Builder pq = PBRequest.newBuilder();
		pq.setRequestId("12");
		pq.setRequestType(E_REQUESET_TYPE.IDENTIFY_DEFAULT);
		pbMsg.setRequest(pq);
		PBResponse.Builder ps = PBResponse.newBuilder();
		ps.setStatus("0:success");
		pbMsg.setResponse(ps);
		PBDataBlock.Builder pd = PBDataBlock.newBuilder();
		List<PBCandidate> pbList = Lists.newArrayList();
		for (int i = 0 ; i < 5; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("enroll");
			pb.setScaledScore(100 + i);			
			pbList.add(pb.build());
		}
		for (int i = 0 ; i < 4; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("external");
			pb.setScaledScore(10 + i);			
			pbList.add(pb.build());
		}
		
		for (int i = 0 ; i < 7; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("test" );
			pb.setScaledScore(27 + i);			
			pbList.add(pb.build());
		}
		for (int i = 0 ; i < 10; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("xia" + i);
			pb.setScaledScore(100 + i);			
			pbList.add(pb.build());
		}	
		
		Collections.shuffle(pbList); 		
		
		pd.getCandidateListBuilder().addAllCandidates(pbList);
		pd.getCandidateListBuilder().setMore(false);
		
		List<PBDataElement> pbDeList= new ArrayList<>();
		for (int i = 0 ; i < 5; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("read");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		for (int i = 3 ; i < 6; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("rmf");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		for (int i = 1 ; i < 5; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("iris");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		
		for (int i = 5; i < 10; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("face");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}		
		Collections.shuffle(pbDeList); 		
		PBDataGroup.Builder pg = PBDataGroup.newBuilder();
		pg.setGroupName("amr");
		for (int i = 0; i < pbDeList.size(); i++) {
			pg.addDataElement(i, pbDeList.get(i));
		}
		
		
		pd.addDataGroup(pg.build());		
		pbMsg.setDataBlock(pd.build());
		return pbMsg.build();
		
	}

}
