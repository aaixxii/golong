package com.nec.aim.uid.client.proerties;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import com.nec.aim.uid.client.exception.UidClientException;

public class PropertyUtil {
	private String properyFullfileName;
	private Properties prop = new Properties();
	private boolean isLoad;

	public PropertyUtil(String properyFullfileName) {
		this.properyFullfileName = properyFullfileName;
		loadPropertiesFile();
		isLoad = true;

	}

	private void loadPropertiesFile() {
		try (InputStream input = new FileInputStream(properyFullfileName)) {
			prop.load(input);
			isLoad = true;
		} catch (IOException e) {
			throw new UidClientException(e.getMessage(), e);
		}
	}

	/**
	 * 
	 * @return
	 */
	public Set<String> getAllKeySet() {
		if (!isLoad) {
			loadPropertiesFile();
			isLoad = true;
		}
		Set<String> keys = new HashSet<String>();
		Set<Object> sets = prop.keySet();
		Iterator<Object> it = sets.iterator();
		while (it.hasNext()) {
			String tmp = (String) it.next();
			keys.add(tmp);
		}
		return keys;
	}

	/**
	 * 
	 * @param properName
	 * @return
	 */
	public String getPropertyValue(String name) {
		if (!isLoad) {
			loadPropertiesFile();
			isLoad = true;
		}
		return prop.getProperty(name);
	}

	public Integer getPropertyIntValue(String name) {
		if (!isLoad) {
			loadPropertiesFile();
			isLoad = true;
		}
		return Integer.parseInt(prop.getProperty(name));
	}

	public Long getPropertyLongValue(String name) {
		if (!isLoad) {
			loadPropertiesFile();
			isLoad = true;
		}
		return Long.parseLong(prop.getProperty(name));
	}

	public Map<String, Double> getAllValues() {
		if (!isLoad) {
			loadPropertiesFile();
			isLoad = true;
		}
		Map<String, Double> results = new HashMap<>();
		Set<String> keys = new HashSet<String>();
		Set<Object> sets = prop.keySet();
		Iterator<Object> it = sets.iterator();
		while (it.hasNext()) {
			String tmp = (String) it.next();
			keys.add(tmp);
		}
		for (String key : keys) {
			results.put(key, Double.valueOf(prop.getProperty(key)));
		}

		return results;
	}

	public void setPropertyValue(String name, String value) {
		if (!isLoad) {
			loadPropertiesFile();
			isLoad = true;
		}
		prop.setProperty(name, value);
	}

	public int getPropertyCount() {
		if (!isLoad) {
			loadPropertiesFile();
			isLoad = true;
		}
		return prop.size();
	}
}
