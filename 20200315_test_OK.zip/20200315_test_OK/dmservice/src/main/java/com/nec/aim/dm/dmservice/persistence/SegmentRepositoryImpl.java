package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nec.aim.dm.dmservice.entity.SegmentInfo;

@Repository
public class SegmentRepositoryImpl implements SegmentRepository {
	
	@Autowired
    private JdbcTemplate jdbcTemplate;
	
	//private static final String insertSql = "insert into segments_info(external_id,bio_id_start, bio_id_end, binary_length, record_count, version , update_ts) values (?,?,?,?,?,?,CURRENT_TIMESTAMP()";
	private static final String insertSql = "insert into segments_info(segment_id,bio_id_start,bio_id_end, version , update_ts) values (?,?,?,0,CURRENT_TIMESTAMP())";			
	private static final String updateSql = "update segments_info set version =version +1, update_ts =CURRENT_TIMESTAMP() where segment_id =?";
	private static final String updateForSegmentCreatedSql = "update segments_info set version =-1, update_ts =CURRENT_TIMESTAMP() where segment_id =?";	
	private static final String updateAfterDelSql = "update segments_info set  version =version +1, update_ts =CURRENT_TIMESTAMP() where segment_id =?";
			
	private static final String setFaildSegmentVer = "update segments_info  set version = -9, update_ts =CURRENT_TIMESTAMP() where segment_id =?";
	private static final String setSuccessSegmentVer = "update segments_info  set version = -1, update_ts =CURRENT_TIMESTAMP() where segment_id =?";
	private static final String updateAfterNew = "update segments_info set version = ? where segment_id = ?";
	
	@Override
	public void insertSegment(SegmentInfo segInfo) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(insertSql, new Object[] {segInfo.getSegmentId(),segInfo.getBioIdStart(), segInfo.getBioIdEnd()});			
	}
	
	@Override
	public void updateSegment(SegmentInfo segInfo) {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(updateSql, new Object[] {segInfo.getSegmentId()});		
	}

	
	public void updateForSegmentCreated(SegmentInfo segInfo) {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(updateForSegmentCreatedSql, new Object[] {segInfo.getSegmentId()});		
	}

	@Override
	public void updateSegmentAfterDelete(SegmentInfo segInfo) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(updateAfterDelSql, new Object[] {segInfo.getSegmentId()});
	}
	
	@Override
	public void setFaildSegmentVer(SegmentInfo segInfo) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(setFaildSegmentVer, new Object[] {segInfo.getSegmentId()});
	}

	@Override
	public void setSuccessSegmentVer(SegmentInfo segInfo) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(setSuccessSegmentVer, new Object[] {segInfo.getSegmentId()});
	}

	@Override
	public void updateAfterNew(long version, long segmentId) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(updateAfterNew, new Object[] {version, segmentId});
	}
}
