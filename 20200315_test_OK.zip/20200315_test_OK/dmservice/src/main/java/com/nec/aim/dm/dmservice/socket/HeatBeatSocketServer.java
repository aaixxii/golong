package com.nec.aim.dm.dmservice.socket;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class HeatBeatSocketServer  {
	private static Logger logger = LoggerFactory.getLogger(HeatBeatSocketServer.class);
	private int myPort;	
	private int serverSocketTimeout = 6000000;	
	private Selector selector;		
	private ServerSocketChannel serverSocketChannel;
	private String allConnString;
	
	public void start(int port, String conStr) {	
		this.myPort = port;
		this.allConnString = conStr;		
		try {
			selector = Selector.open();
			serverSocketChannel = ServerSocketChannel.open();
			serverSocketChannel.socket().setReuseAddress(true);
			serverSocketChannel.socket().setSoTimeout(serverSocketTimeout);
			serverSocketChannel.configureBlocking(false);			
			serverSocketChannel.socket().bind(new InetSocketAddress(myPort));
			serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);			
		} catch (IOException e) {
			String errmsg = "Can't starting server socket server!";
			logger.error(errmsg);
		}
		logger.info("DM heatbeat socket server is started.");
		 try {
			service();
		} catch (IOException e) {			
			e.printStackTrace();
			close();
		}
	}	
	
	public void service() throws IOException {		
		while (selector.select() > 0) {
			Set<SelectionKey> readyKeys = selector.selectedKeys();
			Iterator<SelectionKey> it = readyKeys.iterator();
			while (it.hasNext()) {
				SelectionKey key = null;
				try {
					key = (SelectionKey) it.next();
					it.remove();
					if (!key.isValid()) {
						continue;
					}
					 if (key.isAcceptable()) {
						 SocketChannel socketChannel = serverSocketChannel.accept();
						socketChannel.configureBlocking(false);	
					        logger.info("Accepted cleint: " + socketChannel.socket().getInetAddress() + ":" + socketChannel.socket().getPort());
					        socketChannel.register(selector, SelectionKey.OP_WRITE);					       					
					 }					 
					 if (key.isWritable()) {
						 String myIp = getMyIP();
					 	 SocketChannel dmClient = (SocketChannel) key.channel();
					 	 String respose = myIp + " is active!";
					 	ByteBuffer byteBufer = ByteBuffer.wrap(respose.getBytes());
					 	byteBufer.flip();
					 	dmClient.write(byteBufer);					 	 
					 }					 
					
				} catch (Exception e) {
					e.printStackTrace();
					try {
						if (key != null) {
							key.cancel();
							key.channel().close();
						}
					} catch (Exception ex) {
						ex.printStackTrace();
					}
				}
			} // #while
		} // #while
	} 
	
	private String getMyIP() throws Exception {
		String resString = null;
		Enumeration<NetworkInterface> e = NetworkInterface.getNetworkInterfaces();
		boolean stop = false;
		InetAddress myIp = null;
		while (e.hasMoreElements() && !stop) {
			NetworkInterface n = (NetworkInterface) e.nextElement();
			Enumeration<?> ee = n.getInetAddresses();
			while (ee.hasMoreElements()) {
				InetAddress i = (InetAddress) ee.nextElement();
				if (isMyId(i)) {	
					myIp = i;
					stop = true;					
				}
				if (stop) break;
			}
			if (stop) break;
		}
		
		if (myIp != null) {
			resString = myIp.getHostAddress() + " is active";
		} else {
			resString = "";
		}
		return resString;
	}
	
	private boolean isMyId(InetAddress addr) {		
		//String allIp = "192.168.232.143:2181,192.168.232.146:2181,127.0.0.1:2181";
		String[] ipArr = allConnString.split(",") == null || allConnString.split(",").length < 0 ? new String[] {} :  allConnString.split(",") ;
		if (ipArr.length > 0) {
			for (String arr : ipArr) {
				int index = arr.indexOf(":");
				String ip = arr.substring(0, index);
				if (addr.getHostAddress().equals(ip)) {
					return true;
				}			
			}			
		}
		return false;
	}
	
	public void close() {
		if (serverSocketChannel != null && serverSocketChannel.isOpen()) {
			try {
				serverSocketChannel.close();
			} catch (IOException e) {
				logger.error(e.getMessage());
			}
		}
		
		if (this.selector != null && this.selector.isOpen()) {
			try {
				this.selector.close();
			} catch (IOException e) {
				logger.error(e.getMessage());
			}
		}		
	}
}
