package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class DmConfigRepositoryImpl implements DmConfigRepository {
	
	private static final String redundancySql = "select key_value from dm_config_info where key_name='redundancy'";
	private static final String maxSegmentSql = "select key_value from dm_config_info where key_name='segment_max_record'";
	
	@Autowired
    private JdbcTemplate jdbcTemplate;

	@Override
	public int getRedundancy() throws SQLException {
		return jdbcTemplate.queryForObject(redundancySql, Integer.class);		
	}

	@Override
	public int getMaxSegmentRecord() throws SQLException {
		return jdbcTemplate.queryForObject(maxSegmentSql, Integer.class);
	}
}
