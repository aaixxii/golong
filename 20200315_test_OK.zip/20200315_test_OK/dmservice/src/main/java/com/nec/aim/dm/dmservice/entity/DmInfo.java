package com.nec.aim.dm.dmservice.entity;

import lombok.Data;

@Data
public class DmInfo {
	String dmId;
	String serverType;
	String hostName;
	String connectionUrl;
}
