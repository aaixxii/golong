package com.nec.aim.dm.dmservice.entity;

import java.sql.Timestamp;


public class SegmentInfo {	
	 private Long segmentId;
	 private Long bioIdStart;	
	 private Long bioIdEnd;	
	 private Long version;
	 private Timestamp updateTs;
	public Long getSegmentId() {
		return segmentId;
	}
	public void setSegmentId(Long segmentId) {
		this.segmentId = segmentId;
	}
	public Long getBioIdStart() {
		return bioIdStart;
	}
	public void setBioIdStart(Long bioIdStart) {
		this.bioIdStart = bioIdStart;
	}
	public Long getBioIdEnd() {
		return bioIdEnd;
	}
	public void setBioIdEnd(Long bioIdEnd) {
		this.bioIdEnd = bioIdEnd;
	}
	public Long getVersion() {
		return version;
	}
	public void setVersion(Long version) {
		this.version = version;
	}
	public Timestamp getUpdateTs() {
		return updateTs;
	}
	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	} 	
}
