package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;
import java.util.List;

import com.nec.aim.dm.dmservice.entity.DmInfo;

public interface DmInfoRepository {
	
	public DmInfo  getDmInfoByDmId(String dmId) throws SQLException;
	public List<String> getAllActiveNodeStorageUrl(int redundancy) throws SQLException;
	public String getNodeStorageUrl(int nodeStorageId) throws SQLException;
}
