package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;

import com.nec.aim.dm.dmservice.entity.SegmentInfo;
import com.nec.aim.dm.dmservice.entity.SegmentLoading;

public interface SegmentLoadRepository {
	
	public void insertSegmentLoad(SegmentLoading segLoad)  throws SQLException;
	public void updateSegmentLoadWithMailFlag(SegmentLoading segLoad)  throws SQLException;	
	public void updateSegmentLoadNoMailFlag(SegmentLoading segLoad)  throws SQLException;
	public void delBioFromSegmentLoadNoMailFlag(SegmentLoading segLoad)  throws SQLException;
}
