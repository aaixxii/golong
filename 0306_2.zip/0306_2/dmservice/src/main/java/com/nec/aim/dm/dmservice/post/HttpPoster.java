package com.nec.aim.dm.dmservice.post;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.aim.dm.dmservice.dispatch.SegmentManager;
import com.nec.aim.dm.dmservice.dispatch.StopWatch;
import com.squareup.okhttp.Call;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;

public class HttpPoster {
	private static Logger logger = LoggerFactory.getLogger(HttpPoster.class);
	private static long postTimeOut = 6000;
	private static final MediaType MEDIA_TYPE_PLAINTEXT = MediaType.parse("text/plain; charset=utf-8");

	public static Boolean post(String url, PBDmSyncRequest dmSegReq) {
		Callable<Boolean> newPostTask = () -> {
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(postTimeOut / 4, TimeUnit.MILLISECONDS);
			client.setReadTimeout(postTimeOut / 4, TimeUnit.MILLISECONDS);
			client.setWriteTimeout(postTimeOut / 2, TimeUnit.MILLISECONDS);
			final StopWatch t = new StopWatch();
			t.start();
			Request request = new Request.Builder().url(url)
					.post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, dmSegReq.toByteArray())).build();
			try {
				Response response = client.newCall(request).execute();				
				t.stop();
				logger.info("Post PBDmSyncRequest(bioId={}) to {} used time={}, and status={}", dmSegReq.getBioId(),
						url, t.elapsedTime(), response.code());
				if (response.isSuccessful()) {
					return Boolean.valueOf(true);
				} else {
					return Boolean.valueOf(false);
				}
				
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
				return Boolean.valueOf(false);
			}
		};
		try {
			return SegmentManager.submit(newPostTask);
		} catch (InterruptedException | ExecutionException e) {
			logger.error(e.getMessage(), e);
			return Boolean.valueOf(false);
		}
	}

	public static byte[] getSegment(String getUrl, Long segId) throws InterruptedException, ExecutionException {
		Callable<byte[]> newGetTask = () -> {
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(postTimeOut / 4, TimeUnit.MILLISECONDS);
			client.setReadTimeout(postTimeOut / 4, TimeUnit.MILLISECONDS);
			client.setWriteTimeout(postTimeOut / 2, TimeUnit.MILLISECONDS);
			final StopWatch t = new StopWatch();
			t.start();
			Request request = new Request.Builder().get().url(getUrl).build();
			Call call = client.newCall(request);
			Response response = call.execute();
			t.stop();
			logger.info("Post getSegment request(segmentId={}) to {} used time={}, and status={}", segId,
					getUrl, t.elapsedTime(), response.code());
			if (response.isSuccessful()) {
				 return response.body().bytes();
			} else {
				return null;
			}			
		};		
		return SegmentManager.submitGetRequest(newGetTask);		
	}
}
