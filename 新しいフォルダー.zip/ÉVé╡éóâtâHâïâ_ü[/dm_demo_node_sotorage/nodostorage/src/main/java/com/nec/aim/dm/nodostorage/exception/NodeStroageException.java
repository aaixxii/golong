package com.nec.aim.dm.nodostorage.exception;
public class NodeStroageException extends RuntimeException {

	private static final long serialVersionUID = 2626082645396399681L;

	public NodeStroageException(String message) {
		super(message);
	}

	public NodeStroageException(Throwable cause) {
		super(cause);
	}

	public NodeStroageException(String message, Throwable cause) {
		super(message, cause);
	}

}
