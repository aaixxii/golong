package com.nec.aim.dm.nodostorage.catchup;

import org.springframework.stereotype.Component;

@Component
public class Heatbeat {
	
	

}
