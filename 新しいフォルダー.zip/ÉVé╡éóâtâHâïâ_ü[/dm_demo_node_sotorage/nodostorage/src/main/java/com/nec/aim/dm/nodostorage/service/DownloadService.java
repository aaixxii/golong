package com.nec.aim.dm.nodostorage.service;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.concurrent.locks.Lock;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.aim.dm.nodostorage.config.ConfigProperties;
import com.nec.aim.dm.nodostorage.manager.NodeStorageManager;
import com.nec.aim.dm.nodostorage.repository.SegmentLoadRepository;
import com.nec.aim.dm.nodostorage.segments.SegmentWriter;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DownloadService {

	@Autowired
	SegmentLoadRepository segmentLoadRepository;

	@Autowired
	ConfigProperties config;

	public byte[] download(HttpServletResponse res, Long segId, long startP, long endP) {
		String downloadPath = config.getPath() + "/" + String.valueOf(segId);
		SegmentWriter segWriter = NodeStorageManager.getSegmentWriter(segId);
		// File file = new File(downloadPath);
		File file = segWriter.getMyFile();		
		if (!file.exists()) {
			log.warn("There are some wrong, the file:{} is not exist!", segId);
			return null;
		}
		long totalSize = file.length();
		if (endP < 0) {
			endP = file.length();
		}
		byte[] byteData = new byte[(int) (endP - startP + 1)];
		RandomAccessFile raf = null;
		Lock readLocker = segWriter.getReadLock();
		readLocker.lock();
		try {
			raf = new RandomAccessFile(file, "rwd");
			raf.seek(startP);
			raf.read(byteData);
			raf.close();
			log.info("Success get segment({}) data", segId);
		} catch (IOException e) {
			log.error(e.getMessage());
		} finally {
			readLocker.unlock();
		}
		long length = byteData.length;
		res.setContentType("application/binary");
		res.addHeader("Content-Length", Long.toString(length));
		// res.setHeader("Content-Disposition", "attachment; filename=" + segmentId + ".seg");		
		res.setHeader("Accept-Ranges", "bytes");
		// Content-Range: bytes 10-1033/304974592
		String contentRange = new StringBuffer("bytes ").append(startP).append("-").append(endP).append("/")
				.append(totalSize).toString();
		res.setHeader("Content-Range", contentRange);		
		// res.setStatus(HttpServletResponse.SC_PARTIAL_CONTENT);
		return byteData;
	}
}
