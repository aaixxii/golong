package com.nec.aim.dm.nodostorage.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
@ConfigurationProperties(prefix = "node.storage")
public class ConfigProperties {
	private String path; //my storage path
	private int space; //my storage space that can used
	private int id; //my storage id
	private String dmId; //my parent table id
	private long heatbeatInterval;
	private long catchUpInterval;
	private int fileWriteTheads;
}
