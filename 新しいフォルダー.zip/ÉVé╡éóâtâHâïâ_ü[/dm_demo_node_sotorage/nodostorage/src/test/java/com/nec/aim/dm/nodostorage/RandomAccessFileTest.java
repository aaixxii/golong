package com.nec.aim.dm.nodostorage;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { NodostorageApplication.class })
public class RandomAccessFileTest {

	@Test
	public void testRandomAccessFile() throws IOException {
		File file = new File("/C:/Users/000001A006PBP/Desktop/test/133_template_data");
		RandomAccessFile raf = new RandomAccessFile(file, "rwd");
		long first = raf.getFilePointer();
		System.out.print(first);
		
		byte[] b = new byte[100];
		raf.readFully(b, 0, 100);
		long second = raf.getFilePointer();
		System.out.print(second);
		

	}

}
