package com.nec.aim.dm.nodostorage;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NodostorageApplicationTests {

	@Test
	void contextLoads() {
	}

}
