package com.nec.aim.dm.dmservice.persistence;



import java.sql.SQLException;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import com.nec.aim.dm.dmservice.DmserviceApplication;
import com.nec.aim.dm.dmservice.entity.DmInfo;

@RunWith(SpringRunner.class)  
@SpringBootTest(classes={DmserviceApplication.class})
public class DmInfoRepositoryImplTest {
	
	@Autowired
    private JdbcTemplate jdbcTemplate;
	
	@Autowired
	DmInfoRepository dmInfoRepository;
	
	@Autowired
	DmConfigRepository dmConfigRepository;


	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetDmInfoByDmId() throws SQLException {
		DmInfo dminfo = dmInfoRepository.getDmInfoByDmId("dm_storage1");
		Assert.assertNotNull(dminfo);
		Assert.assertEquals(dminfo.getDmId(), "dm_storage1");
	}

	@Test
	public void testGetAllActiveNodeStorageUrl() throws SQLException {
		int redandacy = dmConfigRepository.getRedundancy();
		List<String> activeNodeStorages = dmInfoRepository.getAllActiveNodeStorageUrl(redandacy);
		Assert.assertEquals(3, activeNodeStorages.size());		
	}
	
	@Test
	public void testGetNodeStorageUrl() throws SQLException {
		String nodeUrl2 = dmInfoRepository.getNodeStorageUrl(2);
		Assert.assertNotNull(nodeUrl2);
		Assert.assertEquals("http://192.168.22.109:8081", nodeUrl2);
		String nodeUrl1 = dmInfoRepository.getNodeStorageUrl(1);
		Assert.assertNotNull(nodeUrl1);
		Assert.assertEquals("http://192.168.22.109:8080", nodeUrl1);
	}

}
