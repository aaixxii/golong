package com.nec.aim.dm.dmservice.entity;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class SegmentLoading {
	 Integer storage_id;
	 Long segmentId;	
	 Integer status; //assign:0,working:1,complete:2,corrupted:3
	 Long lastVersion;	
	 Timestamp lastTs;	
}
