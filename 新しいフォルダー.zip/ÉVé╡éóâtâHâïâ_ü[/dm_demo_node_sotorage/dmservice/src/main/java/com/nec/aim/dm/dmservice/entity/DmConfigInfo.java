package com.nec.aim.dm.dmservice.entity;
import lombok.Data;

@Data
public class DmConfigInfo {
	
	Integer configId;
	String key_name;
	String key_value;	

}
