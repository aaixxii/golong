package com.nec.aim.uid.client.download;

import static com.nec.aim.uid.client.common.UidClientConstants.JOB_RESULT_PATH;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.aim.uid.client.manager.UidCommonManager;
import com.nec.aim.uid.client.manager.UidDmJobRunManager;
import com.nec.aim.uid.client.util.StopWatch;
import com.squareup.okhttp.Call;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

public class SegmenDownloader {
	private static Logger logger = LoggerFactory.getLogger(SegmenDownloader.class);
	private String downloadUrl;
	private Long segmentId;
	private String savePath;
	private static final long oneDownloadSize = 500000000; // byte
	private static long postTimeOut = 10000;

	public SegmenDownloader(String downloadUrl, Long segmentId) {
		this.downloadUrl = downloadUrl;
		this.segmentId = segmentId;
		String tmpSavePath = UidCommonManager.getValue(JOB_RESULT_PATH);
		this.savePath = tmpSavePath.endsWith("/") ? tmpSavePath + segmentId.toString()
				: tmpSavePath + "/" + segmentId.toString();
	}

	public void download() throws Exception {
		long remoteFileSize = getDownloadFileSize();
		if (remoteFileSize <= oneDownloadSize) {
			byte[] segmentData = downloadSegment();
			saveToFile(0, remoteFileSize, segmentData);
		} else {
			int theadCount = (int) (remoteFileSize / oneDownloadSize);
			for (int i = 0; i < theadCount; i++) {
				long posStart = i * oneDownloadSize + 1l;
				long posEnd = (i + 1) * oneDownloadSize;
				if (i == theadCount - 1) {
					if (posEnd != remoteFileSize) {
						posEnd = remoteFileSize;
					}
				}
				byte[] tmp = downloadUseRegion(posStart, posEnd);
				saveToFile(posStart, posEnd, tmp);
			}
		}
	}

	public long getDownloadFileSize() throws IOException {
		URL url = new URL(downloadUrl);
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod("GET");
		connection.setConnectTimeout(10000);
		int code = connection.getResponseCode();
		if (code == 200) {
			long fileSize = connection.getContentLength();
			connection.disconnect();
			return fileSize;
		}
		return -1;
	}

	public byte[] downloadSegment() throws InterruptedException, ExecutionException {
		Callable<byte[]> newGetTask = () -> {
			final StopWatch t = new StopWatch();
			t.start();
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(postTimeOut / 4, TimeUnit.MILLISECONDS);
			client.setReadTimeout(postTimeOut / 4, TimeUnit.MILLISECONDS);
			client.setWriteTimeout(postTimeOut / 2, TimeUnit.MILLISECONDS);
			Request request = new Request.Builder().get().url(downloadUrl).build();
			Call call = client.newCall(request);
			Response response = call.execute();
			t.stop();
			if (response.code() == 200) {
				logger.info("Send getSegment request(segmentId={}) to {} used time={} and status={}", segmentId,
						downloadUrl, t.elapsedTime(), response.code());
				return response.body().bytes();
			} else {
				logger.warn("Faild to get segment data from dm cluster, sendUrl={} segmentId={} and status={}",
						segmentId, segmentId, response.code());
				return null;
			}
		};
		return UidDmJobRunManager.submitGetRequest(newGetTask);
	}

	public byte[] downloadUseRegion(long startP, long endP) throws InterruptedException, ExecutionException {
		Callable<byte[]> downloadTask = () -> {
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(postTimeOut / 4, TimeUnit.MILLISECONDS);
			client.setReadTimeout(postTimeOut / 4, TimeUnit.MILLISECONDS);
			client.setWriteTimeout(postTimeOut / 2, TimeUnit.MILLISECONDS);
			Request request = new Request.Builder().addHeader("RANGE", "bytes=" + startP + "-" + endP).url(downloadUrl)
					.build();
			try {
				Response response = client.newCall(request).execute();

				if (response.code() == 200) {
					logger.info("Success to getSegment request(segmentId={}) from {} to {}  and status={}", segmentId,
							startP, endP);
					return response.body().bytes();
				} else {
					logger.info("Faild to getSegment request(segmentId={}) from {} to {}  and status={}", segmentId,
							startP, endP);
					return null;
				}

			} catch (IOException e) {
				logger.info(e.getMessage());
				return null;
			}
		};
		return UidDmJobRunManager.submitGetRequest(downloadTask);
	}

	private void saveToFile(long posStart, long posEnd, byte[] data) throws IOException {
		File file = new File(savePath);
		RandomAccessFile randomAccessFile = new RandomAccessFile(file, "rwd");
		randomAccessFile.seek(posStart);
		randomAccessFile.write(data);
		randomAccessFile.close();
	}
}
