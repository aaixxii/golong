package com.nec.aim.dm.nodostorage.repository;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class DmConfigRepositoryImpl implements DmConfigRepository {
	
	private static final String redundancySql = "select key_value from dm_config_info where key_name='redundancy'";	
	private static final String maxSegmentSize = "select key_value from dm_config_info where key_name='max_segment_size'";
	private static final String maxRecordCount = "select key_value from dm_config_info where key_name='segment_max_record'";
	private static final String oneTempalteSize = "select key_value from dm_config_info where key_name='one_template_size'";	
	
	@Autowired
    private JdbcTemplate jdbcTemplate;

	@Override
	public int getRedundancy() throws SQLException {
		return jdbcTemplate.queryForObject(redundancySql, Integer.class);		
	}

	@Override
	public int getMaxSegmentSize() throws SQLException {
		return jdbcTemplate.queryForObject(maxSegmentSize, Integer.class);
	}
	
	@Override
	public int getMaxSegmentRecord() throws SQLException {
		return jdbcTemplate.queryForObject(maxRecordCount, Integer.class);
	}
	
	@Override
	public int getOneTempalteSize() throws SQLException {
		return jdbcTemplate.queryForObject(oneTempalteSize, Integer.class);
	}
}
