package com.nec.aim.dm.dmservice.entity;

import java.sql.Timestamp;

public class SegmentInfo {	
	 private long segmentId;
	 private long bioIdStart;
	 private String externalId;
	 private long bioIdEnd;
	 private  long binaryLegth;
	 private long recordCount;
	 private long version;
	 private Timestamp updateTs;
	public long getSegmentId() {
		return segmentId;
	}
	public void setSegmentId(long segmentId) {
		this.segmentId = segmentId;
	}
	public long getBioIdStart() {
		return bioIdStart;
	}
	public void setBioIdStart(long bioIdStart) {
		this.bioIdStart = bioIdStart;
	}
	public long getBioIdEnd() {
		return bioIdEnd;
	}
	public void setBioIdEnd(long bioIdEnd) {
		this.bioIdEnd = bioIdEnd;
	}
	public long getBinaryLegth() {
		return binaryLegth;
	}
	public void setBinaryLegth(long binaryLegth) {
		this.binaryLegth = binaryLegth;
	}
	public long getRecordCount() {
		return recordCount;
	}
	public void setRecordCount(long recordCount) {
		this.recordCount = recordCount;
	}
	public long getVersion() {
		return version;
	}
	public void setVersion(long version) {
		this.version = version;
	}
	public Timestamp getUpdateTs() {
		return updateTs;
	}
	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}
	public String getExternalId() {
		return externalId;
	}
	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}
	
}
