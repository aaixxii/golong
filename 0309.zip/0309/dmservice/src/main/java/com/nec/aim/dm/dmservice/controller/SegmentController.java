package com.nec.aim.dm.dmservice.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.nec.aim.dm.dmservice.dispatch.Dispatcher;
import com.nec.aim.dm.dmservice.exception.DmServiceException;

import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncResponce;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class SegmentController extends HttpServlet{	
	private static final long serialVersionUID = 8978225136377187339L;
	
	@Autowired
	Dispatcher dispatcher;

	@RequestMapping(value = "/dmSyncSegment", method = RequestMethod.POST)
	public void dmSegmentHandler(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException, DmServiceException, SQLException {
		log.info("Received dmSyncSegment from {}", req.getRemoteHost());
		PBDmSyncResponce.Builder dmRes = PBDmSyncResponce.newBuilder();		
			PBDmSyncRequest dmSegReq =PBDmSyncRequest.parseFrom(req.getInputStream());			
			boolean result = dispatcher.handlePostRequest(dmSegReq);
			dmRes.setSuccess(result);	
			log.info("Got respone from dm cluster, response = {}", result);
			dmRes.build().writeTo(res.getOutputStream());
	}
}
