package com.nec.aim.dm.dmservice.dispatch;

import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nec.aim.dm.dmservice.entity.NodeStorage;
import com.nec.aim.dm.dmservice.entity.SegmentInfo;
import com.nec.aim.dm.dmservice.entity.SegmentLoading;
import com.nec.aim.dm.dmservice.exception.DmServiceException;
import com.nec.aim.dm.dmservice.persistence.DmConfigRepository;
import com.nec.aim.dm.dmservice.persistence.NodeStorageRepository;
import com.nec.aim.dm.dmservice.persistence.SegmentLoadRepository;
import com.nec.aim.dm.dmservice.persistence.SegmentRepository;
import com.nec.aim.dm.dmservice.post.HttpPoster;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBTargetSegmentVersion;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class Dispatcher {

	@Autowired
	NodeStorageRepository nodeRepository;

	@Autowired
	DmConfigRepository dmConfigRepository;

	@Autowired
	SegmentLoadRepository segmentLoadRepository;

	@Autowired
	SegmentRepository segmentRepository;

	@Transactional
	public Boolean handlePostRequest(PBDmSyncRequest dmSegReq) throws SQLException, DmServiceException {
		PBTemplateInfo templateInfo = null;
		String changeType = null;
		long bioId = -9999;
		String externalId = null;
		byte[] templateData = null;
		long segId = -9999;
		long segVer = -9999;
		try {
			changeType = dmSegReq.getCmd().name().toUpperCase();
			bioId = dmSegReq.getBioId();
			if (dmSegReq.hasTemplateData()) {
				templateInfo = dmSegReq.getTemplateData();
				if (templateInfo.hasReferenceId()) {
					externalId = templateInfo.getReferenceId();
				}
				if (templateInfo.hasData()) {
					templateData = templateInfo.getData().toByteArray();
				}
			}			
			segId = dmSegReq.getTargetSegments().getId();
			if (dmSegReq.getTargetSegments().hasVersion()) {
				segVer = dmSegReq.getTargetSegments().getVersion();
			}
			
		} catch (Exception e) {
			throw new DmServiceException(e);
		}

		if (changeType == null || changeType.isEmpty() || externalId == null) {				 
			throw new DmServiceException("Reqeust parameter invaild!");
		}
		SegmentInfo segInfo = new SegmentInfo();
		segInfo.setSegmentId(segId);
		segInfo.setBioIdStart(bioId);
		segInfo.setBioIdEnd(bioId);
		segInfo.setExternalId(externalId);
		segInfo.setVersion(segVer);
		segInfo.setBinaryLegth(templateData == null ? 0: templateData.length);

		int redundancy = dmConfigRepository.getRedundancy();
		List<NodeStorage> activeNodeStorages = nodeRepository.findNeedNodeByRedundancy(templateData.length, redundancy);
		if (activeNodeStorages == null || activeNodeStorages.size() < 1 || redundancy < 0) {
			throw new DmServiceException("No active node storages!");
		}
		boolean mmReturnValue = true;

		if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_NEW.name())) { // add segment			
			mmReturnValue = processNewSegment(activeNodeStorages, segInfo);
		} else if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT.name())) { // update template
			mmReturnValue = processTempalteInsert(activeNodeStorages, segInfo, dmSegReq);
		} else if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE.name())) { // delete template
			mmReturnValue = processTempalteDelete(activeNodeStorages, segInfo, dmSegReq);
		}
		return Boolean.valueOf(mmReturnValue);
	}

	private boolean processNewSegment(List<NodeStorage> activeNodeStorages, SegmentInfo segInfo) throws SQLException {
		SegmentLoading segLoading = new SegmentLoading();
		segLoading.setSegmentId(segInfo.getSegmentId());
		segLoading.setLastVersion(0);
		segInfo.setVersion(0l);
		List<NodeStorage> allNodeStorages = nodeRepository.findAll();
		boolean mmReturnValue = true;
		List<NodeStorage> notActiveNodeStorages = allNodeStorages.stream()
				.filter(one -> !activeNodeStorages.contains(one)).collect(Collectors.toList());

		for (int i = 0; i < activeNodeStorages.size(); i++) {
			NodeStorage one = activeNodeStorages.get(i);
			segLoading.setStorage_id(one.getStorageId());
			segLoading.setStatus(1);			
			try {
				segmentRepository.insertSegment(segInfo);
				segmentLoadRepository.insertSegmentLoad(segLoading);
			} catch (Exception e) {
				throw new DmServiceException(e);
			}
			PBDmSyncRequest.Builder addSegment = PBDmSyncRequest.newBuilder();
			addSegment.setCmd(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_NEW);
			addSegment.setBioId(-9999);
			PBTemplateInfo.Builder emptyTemplate = PBTemplateInfo.newBuilder();
			addSegment.setTemplateData(emptyTemplate);
			PBTargetSegmentVersion.Builder segmentVer = PBTargetSegmentVersion.newBuilder();
			segmentVer.setId(segInfo.getSegmentId());
			segmentVer.setVersion(0);
			addSegment.setTargetSegments(segmentVer.build());
			Boolean result = HttpPoster.post(one.getUrl(), addSegment.build());
			try {
				if (result.booleanValue()) {
					segmentRepository.updateAfterNew(-1, segInfo.getSegmentId());
					segmentLoadRepository.updateAfterNew(-1, one.getStorageId(), segInfo.getSegmentId());
				} else {
					segmentRepository.updateAfterNew(-9, segInfo.getSegmentId());
					segmentLoadRepository.updateAfterNew(-9, one.getStorageId(), segInfo.getSegmentId());
					nodeRepository.setSignalMailFlag(one.getStorageId(), one.getDmStorageid());
				}
			} catch (Exception e) {				
				throw new DmServiceException(e);
			}
			mmReturnValue = mmReturnValue && result.booleanValue();
		}

		segInfo.setVersion(0);
		segLoading.setStatus(0);		
		notActiveNodeStorages.forEach(one -> {
			try {
				segmentRepository.insertSegment(segInfo);
				segmentLoadRepository.insertSegmentLoad(segLoading);
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}
		});
		return mmReturnValue;
	}

	private boolean processTempalteInsert(List<NodeStorage> activeNodeStorages, SegmentInfo segInfo,
			PBDmSyncRequest dmSegReq) {
		boolean mmReturnValue = true;
		SegmentLoading segLoading = new SegmentLoading();
		segLoading.setSegmentId(segInfo.getSegmentId());
		segLoading.setLastVersion(0);
		for (int i = 0; i < activeNodeStorages.size(); i++) {
			NodeStorage one = activeNodeStorages.get(i);
			segLoading.setStorage_id(one.getStorageId());
			Boolean result = null;
			try {
				long nodoSegmentVersion = segmentLoadRepository.getLastVersion(one.getStorageId(), segInfo.getSegmentId());						
				if (segInfo.getVersion() == nodoSegmentVersion + 1) {
					result = HttpPoster.post(one.getUrl(), dmSegReq);
					if (result.booleanValue()) {
						segLoading.setStatus(1);
						segLoading.setLastVersion(segInfo.getVersion());
						segLoading.setDataSize(segInfo.getBinaryLegth());
						segmentRepository.updateSegment(segInfo);
						segmentLoadRepository.updateSegmentLoadNoMailFlag(segLoading);
					}
				} else {
					nodeRepository.setSignalMailFlag(one.getStorageId(), one.getDmStorageid());
				}

			} catch (SQLException e) {
				throw new DmServiceException(e);
			}
			mmReturnValue = mmReturnValue && result.booleanValue();
		}
		return mmReturnValue;
	}

	private boolean processTempalteDelete(List<NodeStorage> activeNodeStorages, SegmentInfo segInfo,
			PBDmSyncRequest dmSegReq) {
		boolean mmReturnValue = true;
		SegmentLoading segLoading = new SegmentLoading();
		segLoading.setSegmentId(segInfo.getSegmentId());		
		for (int i = 0; i < activeNodeStorages.size(); i++) {
			NodeStorage one = activeNodeStorages.get(i);
			segLoading.setStorage_id(one.getStorageId());
			Boolean result = null;
			try {
				long nodoSegmentVersion = segmentLoadRepository.getLastVersion(one.getStorageId(),
						segInfo.getSegmentId());
				if (segInfo.getVersion() == nodoSegmentVersion + 1) {
					result = HttpPoster.post(one.getUrl(), dmSegReq);
					if (result.booleanValue()) {
						segLoading.setLastVersion(segInfo.getVersion());
						//segmentRepository.deleteBioFromSegment(segInfo);
						segmentRepository.updateSegmentAfterDelete(segInfo);
						segmentLoadRepository.delBioFromSegmentLoadNoMailFlag(segLoading);
					}
				} else {
					nodeRepository.setSignalMailFlag(one.getStorageId(), one.getDmStorageid());
				}

			} catch (SQLException e) {
				result = false;
				throw new DmServiceException(e);
			}
			mmReturnValue = mmReturnValue && result.booleanValue();
		}
		return mmReturnValue;
	}

	public byte[] dispatchGetRequest(Long segId) throws InterruptedException, ExecutionException, SQLException {
		List<NodeStorage> activeList = nodeRepository.findAll();
		if (activeList == null || activeList.size() < 1) {
			throw new DmServiceException("No active dm stroage node for process");
		}
		Collections.shuffle(activeList);
		byte[] result = HttpPoster.getSegment(activeList.get(0).getUrl(), segId);
		return result;
	}

}
