package com.nec.aim.dm.dmservice;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DmserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
