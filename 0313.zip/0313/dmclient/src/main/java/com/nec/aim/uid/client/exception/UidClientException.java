package com.nec.aim.uid.client.exception;

public class UidClientException extends RuntimeException {

	private static final long serialVersionUID = 4092967622896782047L;

	/**
	 * @param message
	 */
	public UidClientException(String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public UidClientException(String message, Throwable cause) {
		super(message, cause);
	}
}
