package com.nec.aim.dm.dmservice.entity;

import java.sql.Timestamp;

public class SegmentLoading {
	  int storage_id;
	 long segmentId;	
	 int status; //assign:0,working:1,complete:2,corrupted:3
	 long lastVersion;	
	 Timestamp lastTs;
	public int getStorage_id() {
		return storage_id;
	}
	public void setStorage_id(int storage_id) {
		this.storage_id = storage_id;
	}
	public long getSegmentId() {
		return segmentId;
	}
	public void setSegmentId(long segmentId) {
		this.segmentId = segmentId;
	}
	
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public long getLastVersion() {
		return lastVersion;
	}
	public void setLastVersion(long lastVersion) {
		this.lastVersion = lastVersion;
	}	

	public Timestamp getLastTs() {
		return lastTs;
	}
	public void setLastTs(Timestamp lastTs) {
		this.lastTs = lastTs;
	}
	
	
}
