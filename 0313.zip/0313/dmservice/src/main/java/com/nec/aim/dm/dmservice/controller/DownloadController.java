package com.nec.aim.dm.dmservice.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.concurrent.ExecutionException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.nec.aim.dm.dmservice.dispatch.Dispatcher;
import com.nec.aim.dm.dmservice.exception.DmServiceException;

import lombok.extern.slf4j.Slf4j;



@Controller
@Slf4j
public class DownloadController extends HttpServlet {	
	
	private static final long serialVersionUID = -5673372086651421607L;
	
	@Autowired
	Dispatcher dispatcher;

	@GetMapping("/seg/{Id}")
	public void downloadSegment(HttpServletRequest req, HttpServletResponse res, @PathVariable("Id") Long segId) throws IOException, InterruptedException, ExecutionException, SQLException {
		//Long segmentId = new Long(req.getPathInfo().substring(1));
		Long segmentId = new Long(segId);
		byte[] segmentData = dispatcher.dispatchGetRequest(segmentId);
		//byte[] segmentData = "uid dm prototype test".getBytes();
		if (segmentData != null && segmentData.length > 0) {
			long length = segmentData.length;
			res.setContentType("application/binary");
			res.addHeader("Content-Length", Long.toString(length));
			//res.setHeader("Content-Disposition", "attachment; filename=" + segmentId + ".seg");
			res.getOutputStream().write(segmentData);
			res.setStatus(200);
			log.info("Success send segment data to mu, segmentId={}", segmentId);
		} else {
			throw new DmServiceException("Faild to get segment data");
		}
	}	
}
